/*Creation de la base de donnee et des tables*/

CREATE DATABASE gestion_projet_entreprise
ON PRIMARY
(
	NAME=gestion_projet_data01,
	FILENAME="C:\ProjetFinal\DATA\gestion_projet_data01.mdf",
	SIZE=100MB,
	FILEGROWTH=0
)
LOG ON
(
	NAME=gestion_projet_log01,
	FILENAME="C:\ProjetFinal\LOG\gestion_projet_log01.ldf",
	SIZE=50MB,
	FILEGROWTH=0
)COLLATE FRENCH_CS_AS
GO

USE gestion_projet_entreprise
GO

CREATE TABLE Services
(
	num_serv INT PRIMARY KEY IDENTITY(1,1),
	nom_serv VARCHAR(50) NOT NULL,
	date_creation DATE NOT NULL
)
GO

CREATE TABLE Employe
(
	matricule INT PRIMARY KEY IDENTITY(1,1),
	nom VARCHAR(50) NOT NULL,
	prenom VARCHAR(50) NOT NULL,
	date_naissance DATE NOT NULL,
	adresse VARCHAR(100) NOT NULL,
	salaire	FLOAT NOT NULL,
	grade VARCHAR(50) NOT NULL,
	num_serv INT FOREIGN KEY(num_serv) REFERENCES Services(num_serv) NOT NULL
)
GO

CREATE TABLE Projet
(
	num_proj INT PRIMARY KEY IDENTITY(1,1),
	nom_proj VARCHAR(50) COLLATE FRENCH_CS_AS NOT NULL,
	lieu VARCHAR(50) NOT NULL,
	nbr_limite_taches INT NOT NULL,
	num_serv INT FOREIGN KEY(num_serv) REFERENCES Services(num_serv) NOT NULL
)
GO

CREATE TABLE Tache
(
	num_tach INT PRIMARY KEY,
	nom_tach VARCHAR(50) NOT NULL,
	date_debut DATE NOT NULL,
	date_fin DATE NOT NULL,
	cout FLOAT NOT NULL,
	num_prj INT FOREIGN KEY(num_prj) REFERENCES Projet(num_proj) NOT NULL
)
GO

CREATE TABLE Travail
(
	matricule INT FOREIGN KEY(matricule) REFERENCES Employe(matricule),
	num_tach INT FOREIGN KEY(num_tach) REFERENCES Tache(num_tach),
	nombre_heure INT NOT NULL,
	PRIMARY KEY(matricule,num_tach)
)
GO

/*ajout des contraintes*/
USE gestion_projet_entreprise
GO


ALTER TABLE Employe
ADD CONSTRAINT ck_age CHECK(YEAR(GETDATE())-YEAR(date_naissance)>18
	 OR (YEAR(GETDATE())-YEAR(date_naissance)=18 AND MONTH(GETDATE())-MONTH(date_naissance)>0)
	 OR (YEAR(GETDATE())-YEAR(date_naissance)=18 AND MONTH(GETDATE())-MONTH(date_naissance)=0 
	 AND DAY(GETDATE())-DAY(date_naissance)>=0))
GO

ALTER TABLE Tache
ADD CONSTRAINT ck_duree CHECK(DATEDIFF(DAY,date_debut,date_fin)>=3)
GO

ALTER TABLE Tache
ADD CONSTRAINT ck_cout CHECK(cout>=DATEDIFF(DAY,date_debut,date_fin)*1000)
GO

ALTER TABLE Services 
ADD CONSTRAINT ck_nom_serv UNIQUE(nom_serv)
GO

ALTER TABLE Employe ADD age AS (DATEDIFF(YEAR,date_naissance,GETDATE()))
GO

