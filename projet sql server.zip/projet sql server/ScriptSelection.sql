/*Requete sql de selection*/
USE gestion_projet_entreprise
GO

/*1*/
SELECT * FROM Mon_projet.Employe WHERE nom LIKE 'El%' AND nom NOT LIKE '%[a-f]' ORDER BY date_naissance
GO

/*2*/
SELECT UPPER(nom_tach) FROM Mon_projet.Tache WHERE YEAR(date_fin) = YEAR(GETDATE()) 
AND MONTH(date_fin) = MONTH(GETDATE())
GO

/*3*/
SELECT COUNT(*) AS nombre_grade_different FROM 
( SELECT grade FROM Mon_projet.Employe GROUP BY grade ) AS grade
GO

/*4*/
SELECT Mon_projet.Employe.matricule,Mon_projet.Employe.nom,Mon_projet.Employe.prenom 
FROM Mon_projet.Employe INNER JOIN Mon_projet.Travail ON Mon_projet.Employe.matricule = Mon_projet.Travail.matricule
INNER JOIN Mon_projet.Tache ON Mon_projet.Travail.num_tach = Mon_projet.Tache.num_tach
INNER JOIN Mon_projet.Projet ON Mon_projet.Tache.num_prj = Mon_projet.Projet.num_proj
INNER JOIN Mon_projet.Services ON Mon_projet.Projet.num_serv = Mon_projet.Services.num_serv
WHERE Mon_projet.Services.num_serv != Mon_projet.Employe.num_serv 
GROUP BY Mon_projet.Employe.matricule,Mon_projet.Employe.nom,Mon_projet.Employe.prenom
GO

/*5*/
SELECT Mon_projet.Projet.num_proj,Mon_projet.Projet.nom_proj,Mon_projet.Projet.lieu,
Mon_projet.Projet.nbr_limite_taches,Mon_projet.Projet.num_serv
FROM Mon_projet.Projet INNER JOIN Mon_projet.Tache ON Mon_projet.Projet.num_proj = Mon_projet.Tache.num_prj
WHERE Mon_projet.Projet.num_proj IN (
SELECT Mon_projet.Projet.num_proj FROM Mon_projet.Projet INNER JOIN Mon_projet.Tache 
ON Mon_projet.Projet.num_proj = Mon_projet.Tache.num_prj 
WHERE  DATEDIFF(DAY,Mon_projet.Tache.date_debut,Mon_projet.Tache.date_fin)<=30
)
AND DATEDIFF(DAY,Mon_projet.Tache.date_debut,Mon_projet.Tache.date_fin)>=60
GO 

/*6*/
SELECT SUM(Mon_projet.Travail.nombre_heure) as masse_horaire FROM Mon_projet.Travail 
INNER JOIN Mon_projet.Tache ON Mon_projet.Travail.num_tach = Mon_projet.Tache.num_tach
WHERE YEAR(Mon_projet.Tache.date_fin) = YEAR(GETDATE()) AND YEAR(Mon_projet.Tache.date_debut) = YEAR(GETDATE())

/*7*/
SELECT Mon_projet.Employe.matricule,Mon_projet.Employe.nom FROM Mon_projet.Employe 
INNER JOIN Mon_projet.Travail ON Mon_projet.Employe.matricule = Mon_projet.Travail.matricule
INNER JOIN Mon_projet.Tache ON Mon_projet.Travail.num_tach = Mon_projet.Tache.num_tach
INNER JOIN Mon_projet.Projet ON Mon_projet.Tache.num_prj = Mon_projet.Projet.num_proj
GROUP BY Mon_projet.Employe.matricule,Mon_projet.Employe.nom 
HAVING COUNT(DISTINCT(Mon_projet.Projet.num_proj)) >=2
GO

/*8*/
SELECT matricule,nom,date_naissance,adresse FROM Mon_projet.Employe 
WHERE DATEADD(YEAR,DATEDIFF(YEAR,date_naissance,GETDATE()),date_naissance)
BETWEEN DATEADD(DAY,7-DATEPART(WEEKDAY,GETDATE()) + 1,GETDATE()) 
AND DATEADD(DAY,7-DATEPART(WEEKDAY,GETDATE()) + 7,GETDATE())

/*9*/
SELECT Projet.num_proj,Projet.nom_proj,Projet.nbr_limite_taches,Projet.lieu,Projet.num_serv
FROM Mon_projet.Projet INNER JOIN Mon_projet.Tache ON Projet.num_proj = Tache.num_prj 
GROUP BY  Projet.num_proj,Projet.nom_proj,Projet.nbr_limite_taches,Projet.lieu,Projet.num_serv
HAVING COUNT(*) = ( SELECT MAX(nbr_tache) FROM (SELECT COUNT(Projet.num_proj) as nbr_tache
FROM Mon_projet.Projet INNER JOIN Mon_projet.Tache ON Projet.num_proj = Tache.num_prj 
GROUP BY Projet.num_proj) AS nombre_tache)

/*10*/
SELECT Projet.num_proj, DATEDIFF(DAY,MIN(Tache.date_debut),MAX(Tache.date_fin)) AS duree_en_jour
FROM Mon_projet.Tache INNER JOIN Mon_projet.Projet ON Tache.num_prj = Projet.num_proj GROUP BY Projet.num_proj 

/*Requete update*/
/*1*/
UPDATE Mon_projet.Employe SET salaire = salaire + salaire*(0.5/100) WHERE age BETWEEN 58 AND 60
GO

UPDATE Employe SET salaire = salaire + salaire*(0.7/100) WHERE age > 60
GO

/*2*/
DELETE FROM Tache WHERE GETDATE() > date_fin AND num_tach NOT IN (SELECT Travail.num_tach FROM Travail INNER JOIN Tache
ON Travail.num_tach = Tache.num_tach)
GO

